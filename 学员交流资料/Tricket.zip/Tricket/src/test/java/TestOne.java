import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ssm.mapper.user.UserInfoMapper;

/**  
 * 创建时间：2018年9月13日 下午9:44:09   
 * @author 张十一先生 
 * 类说明：  
 */
public class TestOne {
	@Before
	public void init(){
		 org.springframework.context.ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext-dao.xml");
	}
	   @Autowired
		 private UserInfoMapper userMapper ;
  @Test
  public void TestOne() throws Exception{
	userMapper.selectByCardID("083519");
	
  }
}
