package comm;

import java.io.IOException;
import java.io.InputStream;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class UtilsBaseMybatis {
     String resource=null;
     SqlSession sqlSession=null;
     public UtilsBaseMybatis(){
    	 
     }
	public UtilsBaseMybatis(String resource) {
	  this.resource=resource;
   }
	public SqlSession getSqlSession(){
		InputStream stream;
		try {
			stream = Resources.getResourceAsStream(resource);
			SqlSessionFactoryBuilder builder = new SqlSessionFactoryBuilder();
			SqlSessionFactory factory = builder.build(stream);
			sqlSession = factory.openSession(); 
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		return sqlSession;
	}

}
