package com.ssm.service.impl.user;

import com.ssm.po.login.Pw_Users_Ex;



/**  
 * 创建时间：2018年9月13日 下午7:10:45   
 * @author 张十一先生 
 * 类说明：  
 */
public interface UserInfoService {
	  //插入用户信息
	  public Integer  insertUser(Pw_Users_Ex info) throws Exception;
	  //根据用户身份证号查找用户信息
	  public Pw_Users_Ex  selectByCardID(String idCard) throws Exception;
}
