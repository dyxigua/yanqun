package com.ssm.mapper.login;

import org.apache.ibatis.annotations.Param;

/**  
 * 创建时间：2018年9月13日 下午4:04:59   
 * @author 张十一先生 
 * 类说明：  
 */
public interface UserLoginInfoMapper {
	//根据账户密码查询用户是否存在
  public Integer UserExist( @Param("username") String username, @Param("password") String password) throws Exception;

}
