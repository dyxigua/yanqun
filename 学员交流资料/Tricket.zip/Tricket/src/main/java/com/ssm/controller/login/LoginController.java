package com.ssm.controller.login;

import javax.servlet.http.HttpSession;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ssm.service.impl.login.LoginService;

/**  
 * 创建时间：2018年9月10日 下午8:29:43   
 * @author 张十一先生 
 * 类说明： 登录前段控制器
 */
@Controller
@RequestMapping("/user")
public class LoginController {
	
	//通过注解获取loginService对象
	@Autowired
	private LoginService loginservice;
	
	
	//跳转到登录界面
	@RequestMapping("/dologin")
	public String doLogin(){
		return "login";
	}
    //登录
	@RequestMapping(value="/login" ,method={RequestMethod.POST,RequestMethod.GET})
	public String login(HttpSession session, @RequestParam(value="username") String username,  String password) throws Exception{
		Integer i=loginservice.UserExist(username, password);
	     if(i!=null&&i>0){
	    	 return "main";
	     }else{
	    	 session.setAttribute("errorMessage", "账户不存在");
	    	 return "redirect:dologin"; 
	     }	
	}  
	//登录成功显示欢迎页面
	 @RequestMapping("/welcome")
	 public String welcome(){
		 return "welcome";
	 }
	
	//退出登录
	@RequestMapping("/loginout")
    public  String loginOut(HttpSession session){
    	session.removeAttribute("username");
    	return "forward:/WEB-INF/jsp/login.jsp";
    }
	
	
}
