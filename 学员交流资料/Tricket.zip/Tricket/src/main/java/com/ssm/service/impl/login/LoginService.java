package com.ssm.service.impl.login;
/**  
 * 创建时间：2018年9月13日 下午4:03:07   
 * @author 张十一先生 
 * 类说明：  
 */
public interface LoginService {
	  public Integer UserExist(String username,String password) throws Exception;
}
