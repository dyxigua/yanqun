package com.ssm.comm;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.core.convert.converter.Converter;



/**  
 * 创建时间：2018年9月6日 下午3:38:27   
 * @author 张十一先生 
 * 类说明：  
 */
public class DateFormat implements Converter<String, Date> {

	@Override
	public Date convert(String str) {
		Date date=null;
		SimpleDateFormat format=new SimpleDateFormat("yyyy年-MM月-dd日");
		try {
			 date=format.parse(str);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}

}
