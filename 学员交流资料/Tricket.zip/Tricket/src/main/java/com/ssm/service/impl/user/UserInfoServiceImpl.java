package com.ssm.service.impl.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssm.mapper.user.UserInfoMapper;
import com.ssm.po.login.Pw_Users_Ex;


/**  
 * 创建时间：2018年9月13日 下午7:11:11   
 * @author 张十一先生 
 * 类说明：  插入用户信息，插入前要检测是否存在该用户，若存在则插入失败
 */
@Service
public class UserInfoServiceImpl implements UserInfoService {
   
	@Autowired
   private UserInfoMapper userdao;
    
   //插入数据
	@Override
	public Integer insertUser(Pw_Users_Ex info) throws Exception {
		
		Integer i=userdao.insertUser(info);
		if(i!=null&&i>0){
			return i;
		}else{
			return -1;
		}
	}
	
		//查询全部信息
	   //根据姓名、身份证号、电话、性别查询、查询用户信息
		//根据ID号删除用户信息
		//修改用户信息
   
	//根据身份证号检查用户是否存在
	@Override
	public Pw_Users_Ex selectByCardID(String idCard) throws Exception {
		System.out.println("服务器收到"+idCard);
		Pw_Users_Ex user=userdao.selectByCardID(idCard);
		if(user!=null){
			return user;
		}
		return null;
	}


}
