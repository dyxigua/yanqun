package com.ssm.service.impl.login;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssm.mapper.login.UserLoginInfoMapper;

/**  
 * 创建时间：2018年9月13日 下午4:03:28   
 * @author 张十一先生 
 * 类说明：  
 */

@Service
public class LoginServiceImpl implements LoginService {
    
	@Autowired
	private UserLoginInfoMapper userdao; 
	@Override
	public Integer UserExist(String username, String password) throws Exception {
		if(username!=null&&password!=null){
		 Integer i=userdao.UserExist(username, password);
		 	if(i!=null){
		 		return i; 
		 	}else{
			 return 0;
		 		}
         }else{
			return -1;
		}
		
	
	}

}
