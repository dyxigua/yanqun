package com.ssm.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

/**  
 * 创建时间：2018年9月10日 下午7:50:49   
 * @author 张十一先生 
 * 类说明：  
 */
public class HandlerInterceptor1 implements HandlerInterceptor {

	
	//执行时机在进入Handler方法之前
	 //可以用于身份认证、身份授权
	//比如身份认证，如果认证失败。需要次方法拦截不在向下执行
	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		  //return false 表示拦截不再放行
		   //return true放行
		 /*System.out.println("  One :preHandle 执行");*/
		return true;
	}
	
  // 进入Handler方法只够，在返回ModelAndView 之前
  // 应用场景从modelAndView出发：可以将公用的模型数据（比如菜单的导航）在这里传到视图，也可以在这里统一指定视图
	 
	@Override
	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
	/*	 System.out.println("  One :postHandle 执行");*/

	}
    //在返回ModelAndView 之后
	//应用场景：统一的异常处理、统一的日志处理
	@Override
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		/* System.out.println("  One :afterCompletion 执行");*/

	}

}
