package com.ssm.po.login;

import java.util.Date;

public class Pw_Users {
    private Integer userId;

    private String userName;

    private String password;

    private String cardCode;

    private Byte sex;

    private Date birthday;

    private String tel;

    private Date createTime;

    private Double accoutNo;

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName == null ? null : userName.trim();
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getCardCode() {
        return cardCode;
    }

    public void setCardCode(String cardCode) {
        this.cardCode = cardCode == null ? null : cardCode.trim();
    }

    public Byte getSex() {
        return sex;
    }

    public void setSex(Byte sex) {
        this.sex = sex;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel == null ? null : tel.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Double getAccoutNo() {
        return accoutNo;
    }

    public void setAccoutNo(Double accoutNo) {
        this.accoutNo = accoutNo;
    }


	@Override
	public String toString() {
		return "Pw_Users [userId=" + userId + ", userName=" + userName
				+ ", password=" + password + ", cardCode=" + cardCode
				+ ", sex=" + sex + ", birthday=" + birthday + ", tel=" + tel
				+ ", createTime=" + createTime + ", accoutNo=" + accoutNo + "]";
	}

	


    
}