package com.ssm.controller.user;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ssm.po.login.Pw_Users_Ex;
import com.ssm.service.impl.user.UserInfoService;

/**  
 * 创建时间：2018年9月13日 下午7:49:07   
 * @author 张十一先生 
 * 类说明：  
 */
@Controller
@RequestMapping("/user")
public class UserRegistController {
  //通过注解获取UserService 实例
	 @Autowired
	 private UserInfoService userservice;
	 
	 
	//注册,用户进入注册页面
		@RequestMapping(value="/doRegist")
		public String doRegist(){
			return "register";
		}
	 
	 //客户端校验检查用户是否已经存在，当前台使用JSon 传值时必须使用@RequestBody注解来接值
	 @RequestMapping(value="/checkIdCard",method={RequestMethod.POST,RequestMethod.GET}, produces = "text/html; charset=utf-8")
	 public @ResponseBody String  checkExit( @RequestBody Pw_Users_Ex ex) {
		 Pw_Users_Ex info;
		try {
			info = userservice.selectByCardID(ex.getCardCode());
			if(info!=null){
				  return "已存在该用户"; 
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			return null;
	 }
	 @RequestMapping(value="/insertUser",method={RequestMethod.POST,RequestMethod.GET}, produces = "text/html; charset=utf-8")
	 public String  insertUser(HttpServletRequest request) {
		 System.out.println("jinlaile");
		Pw_Users_Ex userinfo=new Pw_Users_Ex();
		//通过request获取前台页面输入的信息
		String username=request.getParameter("userName");
		String password=request.getParameter("password");
		String cardCode=request.getParameter("cardCode");
		String sex=request.getParameter("sex");
		String email=request.getParameter("email");
		String tel=request.getParameter("tel");
		//将获取到的信息封装到userinfo中去
		if(username!=null&&password!=null){
			userinfo.setUserName(username);
			userinfo.setPassword(password);
			userinfo.setCardCode(cardCode);
			//将男|女装换为Byte型
			Byte se;
			if(sex.equals("男")){
				 se=0;
			}else{
				se=1;
			}
			userinfo.setSex(se);
			userinfo.setEmail(email);
			userinfo.setTel(tel);
		}else{
			System.out.println("有选项为空");
			return "register";
		}
		System.out.println(userinfo);
		 int i=0;
		 try {
			 i=userservice.insertUser(userinfo);
		} catch (Exception e) {
			e.printStackTrace();
		}
		 if(i>0){
			 return "login";
		}
		 return "error";
		 
		 
		
	 }
		  
		


		
	 
}
