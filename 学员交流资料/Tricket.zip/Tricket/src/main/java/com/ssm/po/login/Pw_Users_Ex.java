package com.ssm.po.login;
/**  
 * 创建时间：2018年9月17日 下午2:48:29   
 * @author 张十一先生 
 * 类说明： 对用户信息的拓展类
 */
public class Pw_Users_Ex extends Pw_Users {
 private String email;

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

/* (non-Javadoc)
 * @see com.ssm.po.login.Pw_Users#toString()
 */
@Override
public String toString() {

	return super.toString();
} 

 
}
